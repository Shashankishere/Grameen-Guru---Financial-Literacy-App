package com.example.grameen_guru;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class LoanCounsellingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loan_counselling);

        // Initialize Views
        ImageView backIcon = findViewById(R.id.back_icon);
        ImageView notificationIcon = findViewById(R.id.notification_icon);

        CardView cardAffordableInvestment = findViewById(R.id.cardLoanCalculator);
        CardView cardLocalEntrepreneurs = findViewById(R.id.cardLoanRecommendations);
        CardView cardGrowthTools = findViewById(R.id.cardLoanEligibiltyCheck);
        CardView cardExpertGuidance = findViewById(R.id.cardPaymentStrategyGuidance);

        // Initialize Spinners for area and bank selection
        Spinner areaSpinner = findViewById(R.id.spinner_area);
        Spinner bankSpinner = findViewById(R.id.spinner_bank);

        // Set up the adapter for Select Your Area Spinner
        ArrayAdapter<CharSequence> areaAdapter = ArrayAdapter.createFromResource(this, R.array.area_array, android.R.layout.simple_spinner_item);
        areaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        areaSpinner.setAdapter(areaAdapter);

        // Set up the adapter for Select Your Bank Spinner
        ArrayAdapter<CharSequence> bankAdapter = ArrayAdapter.createFromResource(this, R.array.bank_array, android.R.layout.simple_spinner_item);
        bankAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        bankSpinner.setAdapter(bankAdapter);

        // Back Button Click Listener
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoanCounsellingActivity.this, DashboardActivity.class);
                startActivity(intent);
                finish(); // Optional: Close current activity
            }
        });

        // Notification Button Click Listener
        notificationIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoanCounsellingActivity.this, NotificationActivity.class);
                startActivity(intent);
            }
        });

        // Card 1: Affordable Investment Click Listener
        cardAffordableInvestment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoanCounsellingActivity.this, LoanCalculatorActivity.class);
                startActivity(intent);
            }
        });

        // Card 2: Support Local Entrepreneurs Click Listener
        cardLocalEntrepreneurs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoanCounsellingActivity.this, LoanRecommendationsActivity.class);
                startActivity(intent);
            }
        });

        // Card 3: Financial Growth Tools Click Listener
        cardGrowthTools.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoanCounsellingActivity.this, LoanEligibilityCheckActivity.class);
                startActivity(intent);
            }
        });

        // Card 4: Expert Guidance Click Listener
        cardExpertGuidance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoanCounsellingActivity.this, PaymentStrategyGuidanceActivity.class);
                startActivity(intent);
            }
        });
    }
}
