package com.example.grameen_guru;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // This links the XML layout

        // Linking XML views with Java variables
        EditText usernameField = findViewById(R.id.username);
        EditText passwordField = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login_button);
        ImageView togglePassword = findViewById(R.id.toggle_password); // Eye icon for toggling password visibility
        TextView forgotPasswordText = findViewById(R.id.forgot_password);// Corrected reference
        ImageView googleIcon = findViewById(R.id.google_icon_image_view); // Corrected reference

        // Handle Password Visibility Toggle
        togglePassword.setOnClickListener(v -> {
            if (passwordField.getInputType() == (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)) {
                // Show password
                passwordField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                togglePassword.setImageResource(R.drawable.ic_eye_on); // Eye open icon
            } else {
                // Hide password
                passwordField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                togglePassword.setImageResource(R.drawable.ic_eye_off); // Eye closed icon
            }
            // Keep cursor at the end of the text
            passwordField.setSelection(passwordField.getText().length());
        });

        // Handle Login Button Click
        loginButton.setOnClickListener(v -> {
            String username = usernameField.getText().toString().trim();
            String password = passwordField.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Handle login logic here (e.g., authenticate user)
                boolean isLoginSuccessful = authenticateUser(username, password); // Replace with actual authentication logic
                if (isLoginSuccessful) {
                    Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();

                    // Navigate to OnboardingActivity
                    Intent intent = new Intent(LoginActivity.this, OnboardingActivity.class);
                    startActivity(intent);
                    finish(); // Close LoginActivity
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle "Forgot Password?" click
        forgotPasswordText.setOnClickListener(v -> {
            // Handle forgot password action
            Toast.makeText(LoginActivity.this, "Forgot Password clicked!", Toast.LENGTH_SHORT).show();
        });

        // Handle Sign Up Button Click
        Button signUpButton = findViewById(R.id.button_sign_up);
        signUpButton.setOnClickListener(v -> {
            // Handle sign-up action
            Toast.makeText(LoginActivity.this, "Sign Up clicked!", Toast.LENGTH_SHORT).show();
        });

        // Handle Google Login Icon Click (Optional)
        googleIcon.setOnClickListener(v -> {
            // Handle Google login action
            Toast.makeText(LoginActivity.this, "Google Login clicked!", Toast.LENGTH_SHORT).show();
        });
    }

    // Simple method to simulate authentication logic (replace with real logic)
    private boolean authenticateUser(String username, String password) {
        // Replace with real authentication logic (e.g., API call, database lookup)
        return username.equals("testuser") && password.equals("password123");
    }
}
