package com.example.grameen_guru;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DashboardActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize BottomNavigationView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        // Find AI Avatar and set its click listener
        ImageView aiAvatar = findViewById(R.id.aiAvatar);
        aiAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, AiAvatarActivity.class);
                startActivity(intent);
            }
        });

        // Find Cards and set their respective click listeners
        findViewById(R.id.cardInvestment).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, InvestmentActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.cardLoanCounselling).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, LoanCounsellingActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.cardExpertLessons).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, ExpertLedLessonsActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.cardPersonalizedProgress).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, PersonalizedProgressActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId(); // Get the selected menu item ID

        if (id == R.id.home) {
            Toast.makeText(this, "Home Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.analytics) {
            Toast.makeText(this, "Analytics Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.profile) {
            Toast.makeText(this, "Profile Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.resources) {
            Toast.makeText(this, "Resources Selected", Toast.LENGTH_SHORT).show();
            return true;
        }

        return false; // Return false if no case matches
    }
}
