package com.example.grameen_guru;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.widget.ImageView;
import android.widget.Toast;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AiAvatarActivity extends AppCompatActivity {

    private static final String OPENAI_API_KEY = "your-openai-api-key"; // Replace with your API key
    private static final String OPENAI_URL = "https://api.openai.com/v1/chat/completions";

    private ImageView aiAvatarImage;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private OkHttpClient httpClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai_avatar);

        // Initialize OkHttpClient
        httpClient = new OkHttpClient();

        // Reference AI Avatar ImageView
        aiAvatarImage = findViewById(R.id.aiAvatar);

        // Request Runtime Permissions
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }

        // Initialize Text-to-Speech
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(Locale.ENGLISH);
            } else {
                Toast.makeText(this, "TTS Initialization Failed", Toast.LENGTH_SHORT).show();
            }
        });

        // Initialize Speech Recognizer
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                Toast.makeText(AiAvatarActivity.this, "Listening...", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onBeginningOfSpeech() {
            }

            @Override
            public void onRmsChanged(float rmsdB) {
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
            }

            @Override
            public void onEndOfSpeech() {
            }

            @Override
            public void onError(int error) {
                Toast.makeText(AiAvatarActivity.this, "Speech Error: " + error, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && matches.size() > 0) {
                    String userInput = matches.get(0); // First result
                    sendToOpenAI(userInput); // Send user input to OpenAI GPT
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
            }
        });

        // Start Listening when the avatar is clicked
        aiAvatarImage.setOnClickListener(view -> startListening());
    }

    // Start the speech recognition process
    private void startListening() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        speechRecognizer.startListening(intent);
    }

    // Send user input to OpenAI GPT and fetch the response
    private void sendToOpenAI(String userInput) {
        // JSON payload
        String jsonPayload = "{"
                + "\"model\":\"gpt-3.5-turbo\","
                + "\"messages\":[{\"role\":\"system\",\"content\":\"You are an AI assistant.\"},"
                + "{\"role\":\"user\",\"content\":\"" + userInput + "\"}],"
                + "\"max_tokens\":100"
                + "}";

        // Create RequestBody
        RequestBody body = RequestBody.create(jsonPayload, MediaType.parse("application/json"));

        // Build Request
        Request request = new Request.Builder()
                .url(OPENAI_URL)
                .addHeader("Authorization", "Bearer " + OPENAI_API_KEY)
                .post(body)
                .build();

        // Make asynchronous network call
        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                runOnUiThread(() -> Toast.makeText(AiAvatarActivity.this, "Failed to connect to OpenAI", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    // Extract GPT's reply from the response JSON
                    String reply = extractReply(responseBody);
                    runOnUiThread(() -> respondToUser(reply));
                } else {
                    runOnUiThread(() -> Toast.makeText(AiAvatarActivity.this, "OpenAI Error: " + response.message(), Toast.LENGTH_SHORT).show());
                }
            }
        });
    }

    // Extract the AI response from the OpenAI JSON response
    private String extractReply(String responseBody) {
        try {
            // Parse JSON and extract the reply (using org.json.JSONObject)
            org.json.JSONObject jsonObject = new org.json.JSONObject(responseBody);
            org.json.JSONArray choices = jsonObject.getJSONArray("choices");
            return choices.getJSONObject(0).getJSONObject("message").getString("content");
        } catch (Exception e) {
            e.printStackTrace();
            return "I'm sorry, I couldn't process that.";
        }
    }

    // Respond to the user using Text-to-Speech
    private void respondToUser(String response) {
        textToSpeech.speak(response, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied! AI Avatar will not work.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        if (textToSpeech != null) {
            textToSpeech.shutdown();
        }
    }
}
