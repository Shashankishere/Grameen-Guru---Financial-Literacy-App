package com.example.grameen_guru;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class OnboardingActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.onboarding_activity);

        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);

        // Set up the adapter for ViewPager2 (ensure you have the right adapter setup)
        OnboardingAdapter adapter = new OnboardingAdapter(this);
        viewPager.setAdapter(adapter);

        // Connect ViewPager2 with TabLayout
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {}).attach();

        // Check if the user is on the last page, and transition to DashboardActivity
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                if (position == adapter.getItemCount() - 1) {
                    // This means user is on the last page, transition to DashboardActivity
                    navigateToDashboard();
                }
            }
        });
    }

    // Method to navigate to DashboardActivity
    private void navigateToDashboard() {
        // Optionally, save the status of onboarding completion
        SharedPreferences.Editor editor = getSharedPreferences("AppPrefs", MODE_PRIVATE).edit();
        editor.putBoolean("onboarding_completed", true);
        editor.apply();

        // Start DashboardActivity
        Intent intent = new Intent(OnboardingActivity.this, DashboardActivity.class);
        startActivity(intent);
        finish(); // Close the onboarding activity
    }
}
