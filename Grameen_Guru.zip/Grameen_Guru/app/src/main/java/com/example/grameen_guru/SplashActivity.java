package com.example.grameen_guru;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.grameen_guru.LoginActivity;
import com.example.grameen_guru.R;
import com.example.grameen_guru.WelcomeActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Delay of 2 seconds before navigating
        new Handler().postDelayed(() -> {
            SharedPreferences sharedPreferences = getSharedPreferences("AppPrefs", MODE_PRIVATE);
            boolean isFirstLaunch = sharedPreferences.getBoolean("isFirstLaunch", true);

            if (isFirstLaunch) {
                // Launch Welcome Activity
                startActivity(new Intent(SplashActivity.this, WelcomeActivity.class));
                sharedPreferences.edit().putBoolean("isFirstLaunch", false).apply();
            } else {
                // Launch Login Activity
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            }

            finish(); // Close SplashActivity
        }, 2000); // 2-second delay
    }
}
