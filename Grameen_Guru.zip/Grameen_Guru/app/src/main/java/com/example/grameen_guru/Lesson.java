package com.example.grameen_guru; // Replace with your package name

public class Lesson {
    private String title;
    private String subtitle;
    private String thumbnailUrl;
    private String videoId;

    // Constructor
    public Lesson(String title, String subtitle, String thumbnailUrl, String videoId) {
        this.title = title;
        this.subtitle = subtitle;
        this.thumbnailUrl = thumbnailUrl;
        this.videoId = videoId;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public String getVideoId() {
        return videoId;
    }

    // (Optional) Setters
}

