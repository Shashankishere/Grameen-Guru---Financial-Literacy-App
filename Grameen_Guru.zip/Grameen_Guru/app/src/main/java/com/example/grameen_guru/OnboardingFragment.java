package com.example.grameen_guru;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

public class OnboardingFragment extends Fragment {

    private static final String ARG_TITLE = "title";
    private static final String ARG_IMAGE = "image";
    private static final String ARG_SHOW_LANGUAGE_DROPDOWN = "showLanguageDropdown";

    private Spinner languageSpinner;
    private Button nextButton;

    // Factory method to create a new instance of this fragment
    public static OnboardingFragment newInstance(String title, int imageRes, boolean showLanguageDropdown) {
        OnboardingFragment fragment = new OnboardingFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TITLE, title);
        args.putInt(ARG_IMAGE, imageRes);
        args.putBoolean(ARG_SHOW_LANGUAGE_DROPDOWN, showLanguageDropdown);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.onboarding_slide, container, false);

        // Initialize views
        TextView titleTextView = view.findViewById(R.id.titleTextView);
        ImageView imageView = view.findViewById(R.id.imageView);
        languageSpinner = view.findViewById(R.id.languageSpinner);
        nextButton = view.findViewById(R.id.nextButton);

        // Set title and image based on arguments
        if (getArguments() != null) {
            titleTextView.setText(getArguments().getString(ARG_TITLE, ""));
            imageView.setImageResource(getArguments().getInt(ARG_IMAGE, 0));
        }

        // Handle language dropdown visibility
        boolean showLanguageDropdown = getArguments() != null && getArguments().getBoolean(ARG_SHOW_LANGUAGE_DROPDOWN, true);
        if (showLanguageDropdown) {
            setupLanguageDropdown(); // Initialize dropdown with language options
            languageSpinner.setVisibility(View.VISIBLE);
        } else {
            languageSpinner.setVisibility(View.GONE);
        }

        // Set up the "Next" button click listener without the English selection check
        nextButton.setOnClickListener(v -> {
            // Move to the next slide
            ViewPager2 viewPager = getActivity() != null ? getActivity().findViewById(R.id.viewPager) : null;
            if (viewPager != null) {
                int currentItem = viewPager.getCurrentItem();
                viewPager.setCurrentItem(currentItem + 1, true);  // Move to the next slide
            }
        });

        return view;
    }

    /**
     * Sets up the language dropdown spinner with options from the resource array.
     */
    private void setupLanguageDropdown() {
        if (getActivity() != null) {
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                    getActivity(),
                    R.array.language_array, // Define this array in res/values/strings.xml
                    android.R.layout.simple_spinner_item
            );
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            languageSpinner.setAdapter(adapter);
        }
    }
}
