package com.example.grameen_guru;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class InvestmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_investment);

        // Initialize Views
        ImageView backIcon = findViewById(R.id.back_icon);
        ImageView notificationIcon = findViewById(R.id.notification_icon);

        CardView cardAffordableInvestment = findViewById(R.id.cardAffordableInvestment);
        CardView cardLocalEntrepreneurs = findViewById(R.id.cardLocalEntrepreneurs);
        CardView cardGrowthTools = findViewById(R.id.cardGrowthTools);
        CardView cardExpertGuidance = findViewById(R.id.cardExpertGuidance);

        // Back Button Click Listener
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InvestmentActivity.this, DashboardActivity.class);
                startActivity(intent);
                finish(); // Optional: Close current activity
            }
        });

        // Notification Button Click Listener
        notificationIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InvestmentActivity.this, NotificationActivity.class);
                startActivity(intent);
            }
        });

        // Card 1: Affordable Investment Click Listener
        cardAffordableInvestment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InvestmentActivity.this, AffordableInvestmentActivity.class);
                startActivity(intent);
            }
        });

        // Card 2: Support Local Entrepreneurs Click Listener
        cardLocalEntrepreneurs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InvestmentActivity.this, LocalEntrepreneursActivity.class);
                startActivity(intent);
            }
        });

        // Card 3: Financial Growth Tools Click Listener
        cardGrowthTools.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InvestmentActivity.this, GrowthToolsActivity.class);
                startActivity(intent);
            }
        });

        // Card 4: Expert Guidance Click Listener
        cardExpertGuidance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InvestmentActivity.this, ExpertGuidanceActivity.class);
                startActivity(intent);
            }
        });
    }
}
