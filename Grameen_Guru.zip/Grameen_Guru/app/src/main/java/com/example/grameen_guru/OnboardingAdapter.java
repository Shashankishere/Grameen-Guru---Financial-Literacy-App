package com.example.grameen_guru;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class OnboardingAdapter extends FragmentStateAdapter {

    public OnboardingAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return OnboardingFragment.newInstance("Your Own Financial Guide", R.drawable.onboarding_image1, false);
            case 1:
                return OnboardingFragment.newInstance("Are You Ready To Take Control?", R.drawable.onboarding_image2, false);
            case 2:
                return OnboardingFragment.newInstance("Please Choose Your Preferred Language", R.drawable.onboarding_image3, true);
            default:
                throw new IllegalArgumentException("Invalid position: " + position);
        }
    }

    @Override
    public int getItemCount() {
        return 3; // Number of onboarding screens
    }
}
